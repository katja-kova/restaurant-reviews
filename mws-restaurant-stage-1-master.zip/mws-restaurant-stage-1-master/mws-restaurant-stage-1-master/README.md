Restaurant Reviews App


# Table of Contents

* [Instructions](#instructions)
* [References](#references)

## Instructions

Download the repository:

* Click download ZIP on the right of the screen, then extract the zip file to your computer, or clone the repository using git.
* Navigate to where you unzipped the file or cloned the repository.
* Double-click index.html to open the game in your browser.

## References

* [Udacity's starter code:](https://github.com/udacity/mws-restaurant-stage-1)
* [The student's project who served me as an example:](https://github.com/stearruda/fend-restaurant-reviews-app)
* [Project 1 MWS Webinar with Doug Brown](https://www.youtube.com/watch?v=92dtrNU1GQc&t=1s)
* [Udacity study jam 3 ( Restaurant review )](https://www.youtube.com/watch?v=TxXwlOAXUko&t=1s)
